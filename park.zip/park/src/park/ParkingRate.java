package park;

import java.util.Calendar;
import java.util.Date;



//Component interface
interface ParkingRate {
    public int calculateRate(int hours);
}

//Concrete component classes
class StudentRate implements ParkingRate {
    public int calculateRate(int hours) {
        return hours * 5;
    }
}

class FacultyRate implements ParkingRate {
    public int calculateRate(int hours) {
        return hours * 8;
    }
}

class StaffRate implements ParkingRate {
    public int calculateRate(int hours) {
        return hours * 10;
    }
}

class VisitorRate implements ParkingRate {
    public int calculateRate(int hours) {
        return hours * 15;
    }
}

//Decorator class
abstract class ParkingRateDecorator{
    protected ParkingRate rate;

    public ParkingRateDecorator(ParkingRate rate) {
        this.rate = rate;
    }

    public int calculateRate(int hours) {
        return rate.calculateRate(hours);
    }
}

//Concrete decorator classes
class EarlyBirdDecorator extends ParkingRateDecorator {
    public EarlyBirdDecorator(ParkingRate rate) {
        super(rate);
    }
 
    public int calculateRate(int hours) {
        return rate.calculateRate(hours);
    }
}

class WeekendDecorator extends ParkingRateDecorator {
    public WeekendDecorator(ParkingRate rate) {
        super(rate);
    }
 
    public int calculateRate(int hours) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        if (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY) {
            return 10;
        } else {
            return rate.calculateRate(hours);
        }
    }
}