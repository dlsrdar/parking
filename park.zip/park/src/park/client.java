package park;

public interface client {
	
	
	public String getemail();
	public String type();
	public String getPassword();
	

}
