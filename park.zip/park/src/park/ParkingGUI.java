package park;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ParkingGUI extends JFrame implements ActionListener {
    
    // GUI components
    private JLabel labelPlate, labelLot, labelAvailable;
    private JTextField fieldPlate;
    private JComboBox<Integer> comboLot;
    private JButton buttonSubmit;
    
    public ParkingGUI() {
    	
    
        // Set up the frame
        setTitle("Parking");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Create the components
        labelPlate = new JLabel("License Plate Number:");
        labelLot = new JLabel("Parking Lot Number:");
        labelAvailable = new JLabel("Parking spot available.");
        fieldPlate = new JTextField(10);
        Integer[] lots = {1, 2}; // Replace with actual lot numbers
        comboLot = new JComboBox<>(lots);
        buttonSubmit = new JButton("Submit");
        buttonSubmit.addActionListener(this);
        
        // Create the layout
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));
        panel.add(labelPlate);
        panel.add(fieldPlate);
        panel.add(labelLot);
        panel.add(comboLot);
        panel.add(labelAvailable);
        panel.add(buttonSubmit);
        
        // Add the panel to the frame
        add(panel);
        
        // Make the frame visible
        setVisible(true);
    }
   
    // Handle button click events
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == buttonSubmit) {
            // Get the information from the GUI
            String plate = fieldPlate.getText();
            int lot = (int) comboLot.getSelectedItem();
            
            // Check if the parking spot is available
            boolean available = checkAvailability(plate, lot);
            
            
            // obervers pattern here track the quantity of the parking space availble 
            
            // Update the label to display the availability
            if (available) {
                labelAvailable.setText("Parking spot available.");
                
                Parkingcharges park = new Parkingcharges();
                dispose();
            } else {
                labelAvailable.setText("Parking spot not available.");
            }
        }
    }
    
    // Replace this method with actual availability checking code
    private boolean checkAvailability(String plate, int lot) {
        // Always returns true for demonstration purposes
        return true;
    }
   
}
